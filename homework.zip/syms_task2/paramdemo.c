#include "linux/module.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Alex L.");

/******* global data *********/

#define MAX_NUM   (const int)1100000000
#define MIN_NUM   (const int)-1100000000

extern int param_random(const int max, const int min, int *r_num);

static int r_num = 0;

int init_module(void)
{
    if(param_random(MAX_NUM, MIN_NUM, &r_num) == 0)
    {
        printk(KERN_ALERT "Random = %d\n", r_num);
    }else{
        return -EINVAL;
    }

    return 0;
}

void cleanup_module(void)
{
    printk(KERN_ALERT "paramdemo exited\n");
    return;
}
