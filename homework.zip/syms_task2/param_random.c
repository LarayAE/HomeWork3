#include "linux/module.h"
#include <linux/random.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Alex L.");

int param_random(const int max, const int min, int *r_num)
{
    int loc_r_num = 0;
    int error = 0;

    get_random_bytes(&loc_r_num, sizeof(loc_r_num));
    
    if((loc_r_num <= max) && (loc_r_num >= min))
    {
        *r_num = loc_r_num;
    }else{
        error = -EINVAL;    
    }

    return error;
}

EXPORT_SYMBOL(param_random);
