#include "linux/module.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Alex L.");

int param_sum(const int *var, const int num)
{
    int i = 0;
    int sum = 0;

    for(i = 0; i < num; i++)
    {
        sum += var[i];
    }

    return sum;
}

EXPORT_SYMBOL(param_sum);
